package com.handpan.keys
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.hypot

/** All geometry is in "units" of a 1080-wide Gboard screenshot, so key proportions match it exactly at any screen width. */
class KeyboardView(private val svc: HandpanService) : View(svc) {
    class Key(val id: String, val x: Float, val w: Float, val row: Int, val special: Boolean = false)
    private class Ripple(val k: Key, val x: Float, val y: Float, val t0: Long)

    private val U = 1080f; private val H = 713f; private val KH = 112f
    private val rowY = floatArrayOf(148f, 290f, 431f, 574f)
    private var hs = 1f; private var accent = Color.parseColor("#FFC27A"); private var rough = -1f
    private var stone: Bitmap? = null
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG); private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = 0xFFD9D9E2.toInt() }
    private val ripples = ArrayList<Ripple>(); private val down = HashMap<Int, Key>()
    private val history = ArrayList<String>(); private val h = Handler(Looper.getMainLooper())
    private var keys = build(false)

    private fun build(sym: Boolean): List<Key> {
        val r0 = if (sym) "1234567890" else "qwertyuiop"; val r1 = if (sym) "@#\$_&-+()" else "asdfghjkl"
        val r2 = if (sym) "*\"':;!?" else "zxcvbnm"
        val l = ArrayList<Key>()
        r0.forEachIndexed { i, c -> l += Key("$c", 13f + i * 106, 92f, 0) }
        r1.forEachIndexed { i, c -> l += Key("$c", 67f + i * 106, 92f, 1) }
        l += Key("SHIFT", 13f, 145f, 2, true)
        r2.forEachIndexed { i, c -> l += Key("$c", 173f + i * 106, 92f, 2) }
        l += Key("DEL", 920f, 146f, 2, true)
        l += Key("SYM", 13f, 145f, 3, true); l += Key(",", 173f, 92f, 3, true); l += Key("IME", 279f, 92f, 3, true)
        l += Key("SPACE", 385f, 413f, 3); l += Key(".", 813f, 92f, 3, true); l += Key("ENTER", 920f, 146f, 3, true)
        return l
    }
    private fun rect(k: Key) = RectF(k.x, rowY[k.row], k.x + k.w, rowY[k.row] + KH)

    fun refresh() {
        hs = svc.p("hs", "1.0").toFloat(); accent = Color.parseColor(svc.p("accent", "#FFC27A"))
        val r = svc.p("texture", "1.0").toFloat()
        if (r != rough) { rough = r; stone = makeStone(r); fill.shader = BitmapShader(stone!!, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
        keys = build(svc.sym); requestLayout(); invalidate()
    }

    /** Dark grey procedural rock: 5 octaves of smooth value noise + speckle. */
    private fun makeStone(rough: Float): Bitmap {
        val n = 256; val rnd = Random(7); val acc = FloatArray(n * n); var amp = 1f; var tot = 0f
        for (g in intArrayOf(4, 8, 16, 32, 64)) {
            val grid = FloatArray((g + 1) * (g + 1)) { rnd.nextFloat() }
            for (y in 0 until n) for (x in 0 until n) {
                val fx = x * g / n.toFloat(); val fy = y * g / n.toFloat(); val x0 = fx.toInt(); val y0 = fy.toInt()
                val tx = fx - x0; val ty = fy - y0; val w = g + 1
                val a = grid[y0 * w + x0]; val b = grid[y0 * w + x0 + 1]; val c = grid[(y0 + 1) * w + x0]; val d = grid[(y0 + 1) * w + x0 + 1]
                acc[y * n + x] += amp * ((a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty)
            }
            tot += amp; amp *= 0.6f
        }
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888); val px = IntArray(n * n)
        for (i in px.indices) {
            val v = acc[i] / tot - 0.5f
            val g = (34 + v * 260f * rough + rnd.nextInt(13) - 6).toInt().coerceIn(12, 78)
            px[i] = Color.rgb(g, g, (g + 2).coerceAtMost(255))
        }
        bmp.setPixels(px, 0, n, 0, 0, n, n); return bmp
    }

    override fun onMeasure(w: Int, hh: Int) {
        val width = MeasureSpec.getSize(w); setMeasuredDimension(width, (H * hs * width / U).toInt())
    }

    override fun onDraw(c: Canvas) {
        val s = width / U; c.save(); c.scale(s, s * hs)
        c.drawColor(0xFF1C1D27.toInt())
        // top bar: settings grid + last notes played
        p.style = Paint.Style.FILL; p.color = 0xFFE0E0EC.toInt()
        for (i in 0..1) for (j in 0..1) c.drawRoundRect(40f + i * 31, 29f + j * 31, 67f + i * 31, 56f + j * 31, 7f, 7f, p)
        text.textSize = 56f; text.color = 0xFFE0E0EC.toInt()
        for (i in 0..2) c.drawText(history.getOrNull(history.size - 3 + i) ?: if (i == 1) "♪" else "", 260f + i * 277, 78f, text)
        p.color = 0xFF3A3B4A.toInt(); c.drawRect(390f, 20f, 392f, 92f, p); c.drawRect(684f, 20f, 686f, 92f, p)
        val now = System.currentTimeMillis(); val showLetters = svc.b("show_letters", true); val showNotes = svc.b("show_notes", true)
        for (k in keys) {
            val r = rect(k); val pressed = down.containsValue(k)
            p.color = 0x99000000.toInt(); c.drawRoundRect(r.left, r.top + 5, r.right, r.bottom + 5, 20f, 20f, p)
            c.drawRoundRect(r, 20f, 20f, fill)
            if (k.special) { p.color = 0x553A3A66; c.drawRoundRect(r, 20f, 20f, p) }
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f; p.color = 0x30FFFFFF; c.drawRoundRect(r, 20f, 20f, p)
            p.style = Paint.Style.FILL
            if (pressed) { p.color = (accent and 0xFFFFFF) or 0x55000000; c.drawRoundRect(r, 20f, 20f, p) }
            val lab = when (k.id) { "SHIFT" -> "⇧"; "DEL" -> "⌫"; "ENTER" -> "⏎"; "SYM" -> if (svc.sym) "abc" else "?123"; "IME" -> "🌐"; "SPACE" -> ""; else -> if (svc.shift) k.id.uppercase() else k.id }
            if (lab.isNotEmpty() && (showLetters || k.special)) {
                text.color = if (k.id == "SHIFT" && svc.shift) accent else 0xFFD9D9E2.toInt()
                text.textSize = if (lab.length > 1 && k.id != "IME") 36f else 48f
                c.drawText(lab, r.centerX(), r.centerY() - (text.ascent() + text.descent()) / 2, text)
            }
            if (k.id == "SPACE") { text.color = 0x66D9D9E2; text.textSize = 28f; c.drawText(svc.scaleName(), r.centerX(), r.centerY() + 10f, text) }
            if (showNotes && !svc.sym) svc.noteName(k.id)?.let { text.color = (accent and 0xFFFFFF) or 0xCC000000.toInt(); text.textSize = 22f; c.drawText(it, r.right - 22f, r.top + 28f, text) }
        }
        if (svc.b("ripple", true)) {
            val it = ripples.iterator()
            while (it.hasNext()) {
                val rp = it.next(); val t = (now - rp.t0) / 650f
                if (t >= 1f) { it.remove(); continue }
                c.save(); val path = Path().apply { addRoundRect(rect(rp.k), 20f, 20f, Path.Direction.CW) }; c.clipPath(path)
                p.style = Paint.Style.FILL; p.color = (accent and 0xFFFFFF) or ((1 - t) * 60).toInt().shl(24); c.drawCircle(rp.x, rp.y, t * 170f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 6f; p.color = (accent and 0xFFFFFF) or ((1 - t) * 220).toInt().shl(24); c.drawCircle(rp.x, rp.y, t * 170f, p)
                c.restore()
            }
            if (ripples.isNotEmpty()) postInvalidateOnAnimation()
        }
        c.restore()
    }

    private fun hit(x: Float, y: Float): Key? = keys.filter { rect(it).also { r -> r.inset(-7f, -15f) }.contains(x, y) }
        .minByOrNull { val r = rect(it); hypot(x - r.centerX(), y - r.centerY()) }

    private val repeat = object : Runnable { override fun run() { down.values.firstOrNull { it.id == "DEL" }?.let { svc.press(it); h.postDelayed(this, 60) } } }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val s = width / U; val sy = s * hs
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex; val x = e.getX(i) / s; val y = e.getY(i) / sy
                if (y < 130f && x < 130f) { svc.openSettings(); return true }
                val k = hit(x, y) ?: return true
                down[e.getPointerId(i)] = k; svc.noteName(k.id)?.let { history.add(it); if (history.size > 6) history.removeAt(0) }
                ripples += Ripple(k, x, y, System.currentTimeMillis()); svc.press(k)
                if (k.id == "DEL") h.postDelayed(repeat, 400)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> if (svc.b("glide", true)) for (i in 0 until e.pointerCount) {
                val id = e.getPointerId(i); val k = hit(e.getX(i) / s, e.getY(i) / sy) ?: continue
                val old = down[id]
                if (old != null && old !== k && k.id.length == 1 && old.id.length == 1) {
                    down[id] = k; svc.sound(k); svc.noteName(k.id)?.let { history.add(it) }
                    ripples += Ripple(k, e.getX(i) / s, e.getY(i) / sy, System.currentTimeMillis()); invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id = e.getPointerId(e.actionIndex)
                if (e.actionMasked == MotionEvent.ACTION_CANCEL) down.clear() else down.remove(id)
                h.removeCallbacks(repeat); invalidate()
            }
        }
        return true
    }
}
