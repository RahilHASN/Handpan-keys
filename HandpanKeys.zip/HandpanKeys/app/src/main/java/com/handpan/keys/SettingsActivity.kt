package com.handpan.keys
import android.content.Intent
import android.os.Bundle
import android.preference.PreferenceActivity
import android.provider.Settings
import android.view.inputmethod.InputMethodManager

@Suppress("DEPRECATION")
class SettingsActivity : PreferenceActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        addPreferencesFromResource(R.xml.settings)
        findPreference("enable_ime").setOnPreferenceClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)); true }
        findPreference("pick_ime").setOnPreferenceClickListener {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker(); true }
    }
}
