package com.handpan.keys
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.preference.PreferenceManager
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import java.io.File
import kotlin.math.pow

class HandpanService : InputMethodService() {
    companion object {
        const val ORDER = "zxcvbnmasdfghjklqwertyuiop" // low pitch -> high pitch
        val NAMES = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
        val SCALES = mapOf("kurd" to intArrayOf(0, 2, 3, 5, 7, 8, 10), "hijaz" to intArrayOf(0, 1, 4, 5, 7, 8, 10),
            "pent" to intArrayOf(0, 3, 5, 7, 10), "major" to intArrayOf(0, 2, 4, 7, 9))
    }
    lateinit var prefs: SharedPreferences
    private var pool: SoundPool? = null
    private var ids = HashMap<String, Int>()
    private var kbd: KeyboardView? = null
    var shift = false; var sym = false
    private var shown = false; private var droneStream = 0
    private val main = Handler(Looper.getMainLooper())
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, k ->
        if (k in setOf("scale", "root", "octave", "sustain", "reverb")) loadSounds()
        if (k == "drone" || k == "volume") updateDrone()
        kbd?.refresh()
    }

    fun p(k: String, d: String) = prefs.getString(k, d) ?: d
    fun b(k: String, d: Boolean) = prefs.getBoolean(k, d)

    override fun onCreate() {
        super.onCreate()
        prefs = PreferenceManager.getDefaultSharedPreferences(this)
        prefs.registerOnSharedPreferenceChangeListener(listener)
        loadSounds()
    }
    override fun onDestroy() { prefs.unregisterOnSharedPreferenceChangeListener(listener); pool?.release(); super.onDestroy() }
    override fun onCreateInputView(): View { kbd = KeyboardView(this); return kbd!! }
    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) { sym = false; shift = false; shown = true; updateDrone(); kbd?.refresh() }
    override fun onFinishInputView(finishingInput: Boolean) { shown = false; updateDrone(); super.onFinishInputView(finishingInput) }

    /** Soft looping root-chord hum under your typing (setting: Drone). */
    fun updateDrone() {
        val sp = pool ?: return
        if (droneStream != 0) { sp.stop(droneStream); droneStream = 0 }
        if (!b("drone", false) || !shown) return
        val id = ids["DRONE"] ?: return
        val v = p("volume", "0.8").toFloat() * 0.35f
        droneStream = sp.play(id, v, v, 0, -1, 1f)
    }

    private fun base() = 48 + p("root", "2").toInt() + 12 * p("octave", "0").toInt()
    private fun midi(idx: Int): Int {
        val sc = SCALES[p("scale", "kurd")]!!; val bs = base()
        var m = bs + 12 * (idx / sc.size) + sc[idx % sc.size]
        while (m > bs + 36) m -= 12
        return m
    }
    fun noteName(c: String): String? { val i = ORDER.indexOf(c.lowercase()); if (c.length != 1 || i < 0) return null; val m = midi(i); return NAMES[m % 12] + (m / 12 - 1) }
    fun scaleName() = p("scale", "kurd").replaceFirstChar { it.uppercase() }

    private fun loadSounds() {
        Thread {
            val sp = SoundPool.Builder().setMaxStreams(12)
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build()).build()
            val map = HashMap<String, Int>()
            val decay = p("sustain", "3.0").toDouble(); val rev = p("reverb", "0.35").toDouble()
            fun add(name: String, hz: Double, kind: Int) {
                val f = File(cacheDir, "n_$name.wav"); f.writeBytes(Synth.wav(hz, decay, rev, kind)); map[name] = sp.load(f.path, 1)
            }
            fun hz(m: Int) = 440.0 * 2.0.pow((m - 69) / 12.0)
            for (i in ORDER.indices) add(ORDER[i].toString(), hz(midi(i)), 0)
            add("SPACE", hz(base() - 12), 0)
            add("tick", hz(base()), 1)
            File(cacheDir, "n_drone.wav").also { it.writeBytes(Synth.drone(listOf(hz(base() - 12), hz(base()), hz(base() + 7)))) }.let { map["DRONE"] = sp.load(it.path, 1) }
            sp.setOnLoadCompleteListener { _, sid, _ -> if (sid == map["DRONE"]) main.post { updateDrone() } }
            val old = pool; droneStream = 0; ids = map; pool = sp; old?.release()
        }.start()
    }

    fun sound(k: KeyboardView.Key) {
        if (!b("sound_on", true)) return
        val id = ids[k.id.lowercase()] ?: ids[if (k.id == "SPACE") "SPACE" else "tick"] ?: return
        val v = p("volume", "0.8").toFloat()
        pool?.play(id, v, v, 1, 0, 1f)
    }
    private fun buzz() {
        if (!b("haptic", true)) return
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        v.vibrate(VibrationEffect.createOneShot(p("haptic_ms", "12").toLong(), 80))
    }
    fun openSettings() = startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    fun press(k: KeyboardView.Key) {
        sound(k); buzz()
        val ic = currentInputConnection ?: return
        when (k.id) {
            "SHIFT" -> shift = !shift
            "SYM" -> sym = !sym
            "IME" -> switchToNextInputMethod(false)
            "DEL" -> ic.deleteSurroundingText(1, 0)
            "SPACE" -> ic.commitText(" ", 1)
            "ENTER" -> {
                val o = currentInputEditorInfo?.imeOptions ?: 0; val a = o and EditorInfo.IME_MASK_ACTION
                if (o and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0 || a == EditorInfo.IME_ACTION_NONE || a == EditorInfo.IME_ACTION_UNSPECIFIED) {
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER)); ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                } else ic.performEditorAction(a)
            }
            else -> { ic.commitText(if (shift) k.id.uppercase() else k.id, 1); if (shift) shift = false }
        }
        kbd?.refresh()
    }
}
