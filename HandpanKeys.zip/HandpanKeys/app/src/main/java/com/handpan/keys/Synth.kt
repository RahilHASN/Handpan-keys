package com.handpan.keys
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/** Builds a handpan-like tone (fundamental + octave + twelfth, fast attack, ringing decay) as WAV bytes. */
object Synth {
    const val SR = 22050
    /** 4 s seamless loop: every partial has a whole number of cycles, slow swell included. */
    fun drone(freqs: List<Double>): ByteArray {
        val n = SR * 4
        val s = DoubleArray(n)
        for (f in freqs) { val ff = round(f * 4) / 4
            for (i in 0 until n) s[i] += sin(2 * PI * ff * i / SR) * (0.8 + 0.2 * sin(2 * PI * i / n)) }
        var pk = 1e-4; for (v in s) pk = max(pk, abs(v))
        val bb = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + n * 2).put("WAVEfmt ".toByteArray())
        bb.putInt(16).putShort(1).putShort(1).putInt(SR).putInt(SR * 2).putShort(2).putShort(16)
        bb.put("data".toByteArray()).putInt(n * 2)
        for (i in 0 until n) bb.putShort((s[i] / pk * 0.6 * 32767).toInt().toShort())
        return bb.array()
    }
    fun wav(freq: Double, decay: Double, reverb: Double, kind: Int): ByteArray {
        val n = SR * 2
        val s = DoubleArray(n)
        for (i in 0 until n) {
            val t = i / SR.toDouble()
            s[i] = if (kind == 0)
                min(1.0, t / 0.004) * (exp(-t * decay) * sin(2 * PI * freq * t) +
                    0.45 * exp(-t * decay * 1.8) * sin(2 * PI * freq * 2 * t) +
                    0.2 * exp(-t * decay * 2.6) * sin(2 * PI * freq * 3.01 * t + 0.3))
            else exp(-t * 26.0) * sin(2 * PI * freq * 0.5 * t) * 0.9 + exp(-t * 300.0) * sin(2 * PI * 1800 * t) * 0.15
        }
        if (reverb > 0) {
            val o = s.copyOf()
            for ((d, g) in listOf(0.043 to 1.0, 0.071 to 0.7, 0.109 to 0.5)) {
                val k = (d * SR).toInt()
                for (i in k until n) s[i] += o[i - k] * reverb * 0.35 * g
            }
        }
        var pk = 1e-4; for (v in s) pk = max(pk, abs(v))
        val bb = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + n * 2).put("WAVEfmt ".toByteArray())
        bb.putInt(16).putShort(1).putShort(1).putInt(SR).putInt(SR * 2).putShort(2).putShort(16)
        bb.put("data".toByteArray()).putInt(n * 2)
        for (i in 0 until n) {
            val fade = if (i > n - 2000) (n - i) / 2000.0 else 1.0
            bb.putShort((s[i] / pk * 0.75 * fade * 32767).toInt().toShort())
        }
        return bb.array()
    }
}
