HANDPAN KEYS - build & install
1. Install Android Studio (Koala or newer). File > Open > select this HandpanKeys folder, let Gradle sync.
2. Plug in your phone (USB debugging on) and press Run, or Build > Build APK(s) and install the APK.
3. Open "Handpan Keys": tap "1. Enable Handpan Keys" and switch it on, then "2. Switch to Handpan Keys".
4. Tap the grid icon at top-left of the keyboard any time to reopen settings.
